﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hadasim4_ex2.Models
{
    public class CoronaSummary
    {
        public DateTime Date { get; set; }
        public int ActivePatients { get; set; }
    }

}
