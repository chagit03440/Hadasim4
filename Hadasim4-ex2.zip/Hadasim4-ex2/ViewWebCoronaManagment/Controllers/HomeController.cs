﻿using Hadasim4_ex2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using ViewWebCoronaManagment.Models;

namespace ViewWebCoronaManagment.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        string BaseUrl = "http://localhost:52469";
        public async Task<IActionResult> IndexAsync()
        {
            DataTable dt = new DataTable();
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.GetAsync($"{BaseUrl}/api/CoronaDetails/GetAllCoronaDetails");

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };
                    var coronaDetails = System.Text.Json.JsonSerializer.Deserialize<Response>(responseContent, options);
                    return View(coronaDetails);
                }
            }
            return View();
        }
        public async Task<IActionResult> ViewAllCoronaDetails()
        {
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.GetAsync($"{BaseUrl}/api/CoronaDetails/GetAllCoronaDetails");

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };
                    var coronaDetails = System.Text.Json.JsonSerializer.Deserialize<Response>(responseContent, options);
                    return View(coronaDetails);
                }
            }

            return View();
        }
        public async Task<IActionResult> ViewAllEmployees()
        {
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.GetAsync($"{BaseUrl}/api/Employee/GetAllEmployees");

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };
                    var employeeName = System.Text.Json.JsonSerializer.Deserialize<Response>(responseContent, options);
                    return View(employeeName);
                }
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddEmployee(Employee employee)
        {
            using (var httpClient = new HttpClient())
            {
                var jsonContent = JsonSerializer.Serialize(employee);
                var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync($"{BaseUrl}/api/Employee/AddEmployee", content);

                if (response.IsSuccessStatusCode)
                {
                    // Employee added successfully, redirect to a success page or return a success message
                    return RedirectToAction("Index");
                }
                else
                {
                    // Handle error response
                    // You may want to display an error message to the user
                    return View("AddEmployee", employee); // Return the AddEmployee view with the submitted data
                }
            }
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
           return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        
    }
}
